lnull=require("lnull")

null=lnull.null()
NULL=null


