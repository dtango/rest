return{
   addon_name = json_content,
   addon_type = 'CONTENT',
   content_types = {["application/json"]=true, ...},
}
