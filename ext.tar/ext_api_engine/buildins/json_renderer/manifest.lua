return {
   addon_name = 'json_renderer',
   addon_type = 'RENDERER',
   accepted_types = {['application/json']=true},
   version = 1.0,
   revision = 0,
}

