return {
   addon_name = 'ps_clixml_renderer',
   addon_type = 'RENDERER',
   accepted_types = {['application/ps_clixml']=true},
   version = 1.0,
   revision = 0,
}

