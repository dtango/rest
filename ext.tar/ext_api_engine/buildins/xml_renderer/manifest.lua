return {
   addon_name = 'xml_renderer',
   addon_type = 'RENDERER',
   accepted_types = {['application/xml']=true, ['text/xml']=true,},
   version = 1.0,
   revision = 0,
}

