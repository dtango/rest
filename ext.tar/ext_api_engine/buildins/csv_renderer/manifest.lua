return {
   addon_name = 'csv_renderer',
   addon_type = 'RENDERER',
   accepted_types = {['text/csv']=true},
   version = 1.0,
   revision = 0,
}

