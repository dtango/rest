return {
   addon_name = 'html_renderer',
   addon_type = 'RENDERER',
   accepted_types = {['text/html']=true},
   version = 1.0,
   revision = 0,
}

