local EEE = {
   NO_RESOURCE = {code=404, msg="Resource not found"}
}

return EEE
